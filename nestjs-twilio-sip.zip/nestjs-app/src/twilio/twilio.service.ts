import { Injectable } from '@nestjs/common';
import * as Twilio from 'twilio';

@Injectable()
export class TwilioService {
  private client;

  constructor() {
    this.client = Twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN,
    );
  }

  async createSipTrunk(friendlyName: string) {
    return this.client.trunking.trunks.create({ friendlyName });
  }

  async listTrunks() {
    return this.client.trunking.trunks.list();
  }

  async handleStatusCallback(payload: any) {
    console.log('Twilio Callback:', payload);
  }
}
