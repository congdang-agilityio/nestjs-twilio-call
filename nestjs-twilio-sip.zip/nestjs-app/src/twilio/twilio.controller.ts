import { Controller, Post, Body, Get } from '@nestjs/common';
import { TwilioService } from './twilio.service';

@Controller('twilio')
export class TwilioController {
  constructor(private readonly twilioService: TwilioService) {}

  @Post('trunk')
  createTrunk(@Body() body: { name: string }) {
    return this.twilioService.createSipTrunk(body.name);
  }

  @Post('callback')
  handleCallback(@Body() payload: any) {
    return this.twilioService.handleStatusCallback(payload);
  }

  @Get('trunks')
  listTrunks() {
    return this.twilioService.listTrunks();
  }
}
