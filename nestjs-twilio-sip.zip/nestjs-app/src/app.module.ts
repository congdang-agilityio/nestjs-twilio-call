import { Module } from '@nestjs/common';
import { TwilioModule } from './twilio/twilio.module';

@Module({
  imports: [TwilioModule],
})
export class AppModule {}
